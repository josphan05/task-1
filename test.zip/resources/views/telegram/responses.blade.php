@extends('layouts.coreui')

@section('title', 'Phản hồi từ Telegram')

@section('breadcrumb')
<ol class="breadcrumb mb-0">
    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
    <li class="breadcrumb-item"><a href="{{ route('telegram.index') }}">Telegram</a></li>
    <li class="breadcrumb-item active">Phản hồi</li>
</ol>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <i class="bi bi-reply-all me-2"></i>
                    <strong>Phản hồi từ Telegram</strong>
                    <span class="badge bg-success ms-2" id="liveIndicator">
                        <i class="bi bi-circle-fill me-1" style="font-size: 0.5rem;"></i> Live
                    </span>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="text-muted small" id="lastUpdate">Đang cập nhật...</span>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="refreshBtn" title="Làm mới">
                        <i class="bi bi-arrow-clockwise"></i>
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <!-- New callbacks notification -->
                <div id="newCallbacksAlert" class="alert alert-info m-3 d-none" role="alert">
                    <i class="bi bi-bell me-2"></i>
                    <span id="newCallbacksCount">0</span> phản hồi mới!
                    <button type="button" class="btn btn-sm btn-info ms-2" onclick="scrollToTop()">
                        Xem ngay
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0" id="callbacksTable">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 60px;">#</th>
                                <th style="width: 200px;">Người phản hồi</th>
                                <th>Nội dung phản hồi</th>
                                <th style="width: 180px;">Thời gian</th>
                            </tr>
                        </thead>
                        <tbody id="callbacksBody">
                            @forelse($callbacks as $callback)
                            <tr data-id="{{ $callback->id }}">
                                <td>
                                    <span class="badge bg-secondary">{{ $callback->id }}</span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-sm me-2" style="width: 32px; height: 32px;">
                                            <img src="https://ui-avatars.com/api/?name={{ urlencode($callback->telegram_full_name) }}&background=0088cc&color=fff&size=32"
                                                 class="rounded-circle"
                                                 alt="{{ $callback->telegram_full_name }}">
                                        </div>
                                        <div>
                                            <div class="fw-semibold">{{ $callback->telegram_full_name }}</div>
                                            @if($callback->telegram_username)
                                            <small class="text-primary">@{{ $callback->telegram_username }}</small>
                                            @endif
                                            @if($callback->user)
                                            <small class="text-muted d-block">
                                                <i class="bi bi-link-45deg"></i> {{ $callback->user->name }}
                                            </small>
                                            @endif
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-primary fs-6 px-3 py-2">
                                        <i class="bi bi-chat-square-text me-1"></i>
                                        {{ $callback->callback_data }}
                                    </span>
                                </td>
                                <td>
                                    <div class="text-muted">
                                        <div>{{ $callback->created_at->format('d/m/Y H:i:s') }}</div>
                                        <small>{{ $callback->created_at->diffForHumans() }}</small>
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr id="emptyRow">
                                <td colspan="4" class="text-center py-5">
                                    <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
                                    <p class="text-muted mt-2 mb-0">Chưa có phản hồi nào</p>
                                    <p class="text-muted small">Gửi tin nhắn có nút tương tác để nhận phản hồi</p>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if($callbacks->hasPages())
                <div class="card-footer">
                    {{ $callbacks->links() }}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

@endsection

@push('styles')
<style>
    .callback-new {
        animation: highlightNew 2s ease-out;
    }

    @keyframes highlightNew {
        0% {
            background-color: rgba(25, 135, 84, 0.3);
        }
        100% {
            background-color: transparent;
        }
    }

    #liveIndicator i {
        animation: pulse 1.5s infinite;
    }

    @keyframes pulse {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.3;
        }
    }

    .table tbody tr {
        transition: background-color 0.3s ease;
    }
</style>
@endpush

@push('scripts')
<script>
$(function () {
    let latestId = {{ $callbacks->first()?->id ?? 0 }};
    let pollInterval = 3000; // Poll every 3 seconds
    let pollTimer = null;
    let newCallbacksCount = 0;

    // Start polling
    function startPolling() {
        pollTimer = setInterval(fetchNewCallbacks, pollInterval);
        updateLastUpdateTime();
    }

    // Stop polling
    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    // Fetch new callbacks
    function fetchNewCallbacks() {
        $.ajax({
            url: '{{ route("telegram.callbacks.new") }}',
            method: 'GET',
            data: { since_id: latestId },
            success: function(response) {
                if (response.success && response.data.length > 0) {
                    // Remove empty row if exists
                    $('#emptyRow').remove();

                    // Add new callbacks to top of table
                    response.data.reverse().forEach(function(callback) {
                        if (callback.id > latestId) {
                            prependCallback(callback);
                            newCallbacksCount++;
                        }
                    });

                    // Update latest ID
                    latestId = response.latest_id;

                    // Show notification
                    if (newCallbacksCount > 0) {
                        showNewCallbacksAlert();
                    }

                    // Play notification sound (optional)
                    playNotificationSound();
                }
                updateLastUpdateTime();
            },
            error: function() {
                console.error('Failed to fetch new callbacks');
            }
        });
    }

    // Prepend new callback to table
    function prependCallback(callback) {
        const linkedUser = callback.user_name
            ? `<small class="text-muted d-block"><i class="bi bi-link-45deg"></i> ${callback.user_name}</small>`
            : '';

        const username = callback.display_name.startsWith('@')
            ? `<small class="text-primary">${callback.display_name}</small>`
            : '';

        const html = `
            <tr data-id="${callback.id}" class="callback-new">
                <td>
                    <span class="badge bg-success">NEW</span>
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-sm me-2" style="width: 32px; height: 32px;">
                            <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(callback.telegram_full_name)}&background=0088cc&color=fff&size=32"
                                 class="rounded-circle"
                                 alt="${callback.telegram_full_name}">
                        </div>
                        <div>
                            <div class="fw-semibold">${callback.telegram_full_name}</div>
                            ${username}
                            ${linkedUser}
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge bg-success fs-6 px-3 py-2">
                        <i class="bi bi-chat-square-text me-1"></i>
                        ${callback.callback_data}
                    </span>
                </td>
                <td>
                    <div class="text-muted">
                        <div>${callback.created_at}</div>
                        <small>${callback.time_ago}</small>
                    </div>
                </td>
            </tr>
        `;

        $('#callbacksBody').prepend(html);

        // Update badge to ID after animation
        setTimeout(function() {
            $(`tr[data-id="${callback.id}"] .badge.bg-success`).first()
                .removeClass('bg-success')
                .addClass('bg-secondary')
                .text(callback.id);
        }, 2000);
    }

    // Show new callbacks alert
    function showNewCallbacksAlert() {
        $('#newCallbacksCount').text(newCallbacksCount);
        $('#newCallbacksAlert').removeClass('d-none');
    }

    // Update last update time
    function updateLastUpdateTime() {
        const now = new Date();
        $('#lastUpdate').text('Cập nhật: ' + now.toLocaleTimeString('vi-VN'));
    }

    // Scroll to top and clear notification
    window.scrollToTop = function() {
        $('html, body').animate({ scrollTop: 0 }, 300);
        $('#newCallbacksAlert').addClass('d-none');
        newCallbacksCount = 0;
    };

    // Play notification sound
    function playNotificationSound() {
        // Create a simple beep using Web Audio API
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            gainNode.gain.value = 0.1;

            oscillator.start();
            oscillator.stop(audioContext.currentTime + 0.1);
        } catch (e) {
            // Ignore audio errors
        }
    }

    // Manual refresh
    $('#refreshBtn').on('click', function() {
        const $btn = $(this);
        $btn.find('i').addClass('spin');
        fetchNewCallbacks();
        setTimeout(function() {
            $btn.find('i').removeClass('spin');
        }, 500);
    });

    // Handle page visibility
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            stopPolling();
        } else {
            startPolling();
            fetchNewCallbacks(); // Fetch immediately when page becomes visible
        }
    });

    // Start polling on page load
    startPolling();
});
</script>
<style>
    .spin {
        animation: spin 0.5s linear;
    }
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
</style>
@endpush

