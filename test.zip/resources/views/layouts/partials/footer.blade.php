<footer class="footer">
    <div>
        Core Laravel &copy; {{ date('Y') }}
    </div>
</footer>

