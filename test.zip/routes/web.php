<?php

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TelegramController;
use App\Http\Controllers\TelegramWebhookController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::middleware(['guest','nocache'])->group(function () {
    Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('login', [AuthController::class, 'login']);
});

// Telegram Webhook (public - no auth required)
Route::post('/telegram/webhook', [TelegramWebhookController::class, 'handle'])
    ->name('telegram.webhook')
    ->withoutMiddleware(['web']);

// Temporary route to set webhook (remove after setup!)
Route::get('/telegram/setup-webhook', function () {
    $service = app(\App\Services\TelegramService::class);
    $url = route('telegram.webhook');
    $result = $service->setWebhook($url);
    return response()->json([
        'webhook_url' => $url,
        'result' => $result,
    ]);
})->name('telegram.setup-webhook');

Route::middleware('auth')->group(function () {
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/', function () {
        return redirect()->route('dashboard');
    });
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('users', UserController::class);

    // Telegram
    Route::get('/telegram', [TelegramController::class, 'index'])->name('telegram.index');
    Route::post('/telegram/send', [TelegramController::class, 'send'])->name('telegram.send');
    Route::get('/telegram/responses', [TelegramController::class, 'responses'])->name('telegram.responses');

    // Telegram Callbacks API (for AJAX polling)
    Route::get('/telegram/callbacks', [TelegramWebhookController::class, 'getCallbacks'])->name('telegram.callbacks');
    Route::get('/telegram/callbacks/new', [TelegramWebhookController::class, 'getNewCallbacks'])->name('telegram.callbacks.new');
});
