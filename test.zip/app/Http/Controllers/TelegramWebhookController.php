<?php

namespace App\Http\Controllers;

use App\Models\TelegramCallback;
use App\Models\User;
use App\Services\TelegramService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class TelegramWebhookController extends Controller
{
    public function __construct(
        protected TelegramService $telegramService
    ) {}

    /**
     * Handle incoming webhook from Telegram
     */
    public function handle(Request $request): JsonResponse
    {
        $data = $request->all();

        Log::info('Telegram webhook received', ['data' => $data]);

        // Handle callback query (button clicks)
        if (isset($data['callback_query'])) {
            return $this->handleCallbackQuery($data['callback_query']);
        }

        // Handle other update types (messages, etc.) if needed
        if (isset($data['message'])) {
            return $this->handleMessage($data['message']);
        }

        return response()->json(['status' => 'ok']);
    }

    /**
     * Handle callback query from inline keyboard button
     */
    protected function handleCallbackQuery(array $callbackQuery): JsonResponse
    {
        $callbackId = $callbackQuery['id'];
        $callbackData = $callbackQuery['data'] ?? '';
        $from = $callbackQuery['from'] ?? [];
        $message = $callbackQuery['message'] ?? [];

        Log::info('Processing callback query', [
            'callback_id' => $callbackId,
            'callback_data' => $callbackData,
            'from' => $from,
        ]);

        // Find linked user by telegram_id
        $telegramUserId = $from['id'] ?? null;
        $user = $telegramUserId
            ? User::where('telegram_id', $telegramUserId)->first()
            : null;

        // Save callback to database
        $callback = TelegramCallback::create([
            'callback_id' => $callbackId,
            'callback_data' => $callbackData,
            'telegram_user_id' => $telegramUserId,
            'telegram_username' => $from['username'] ?? null,
            'telegram_first_name' => $from['first_name'] ?? null,
            'telegram_last_name' => $from['last_name'] ?? null,
            'user_id' => $user?->id,
            'message_id' => $message['message_id'] ?? null,
            'chat_id' => $message['chat']['id'] ?? null,
            'raw_data' => $callbackQuery,
        ]);

        Log::info('Callback saved', ['callback' => $callback->toArray()]);

        // Answer the callback query (removes loading state on button)
        $this->answerCallbackQuery($callbackId, $callbackData);

        return response()->json(['status' => 'ok', 'callback_id' => $callback->id]);
    }

    /**
     * Answer callback query to Telegram
     */
    protected function answerCallbackQuery(string $callbackId, string $callbackData): void
    {
        try {
            $this->telegramService->answerCallbackQuery($callbackId, "Đã nhận: {$callbackData}");
        } catch (\Exception $e) {
            Log::error('Failed to answer callback query', [
                'callback_id' => $callbackId,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Handle incoming message (optional)
     */
    protected function handleMessage(array $message): JsonResponse
    {
        Log::info('Received message', ['message' => $message]);

        return response()->json(['status' => 'ok']);
    }

    /**
     * Get recent callbacks for display
     */
    public function getCallbacks(Request $request): JsonResponse
    {
        $callbacks = TelegramCallback::with('user')
            ->orderBy('created_at', 'desc')
            ->limit($request->input('limit', 50))
            ->get()
            ->map(function ($callback) {
                return [
                    'id' => $callback->id,
                    'callback_data' => $callback->callback_data,
                    'display_name' => $callback->display_name,
                    'telegram_full_name' => $callback->telegram_full_name,
                    'user_name' => $callback->user?->name,
                    'created_at' => $callback->created_at->format('d/m/Y H:i:s'),
                    'time_ago' => $callback->created_at->diffForHumans(),
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $callbacks,
        ]);
    }

    /**
     * Get callbacks since a specific ID (for polling)
     */
    public function getNewCallbacks(Request $request): JsonResponse
    {
        $sinceId = $request->input('since_id', 0);

        $callbacks = TelegramCallback::with('user')
            ->where('id', '>', $sinceId)
            ->orderBy('created_at', 'desc')
            ->get()
            ->map(function ($callback) {
                return [
                    'id' => $callback->id,
                    'callback_data' => $callback->callback_data,
                    'display_name' => $callback->display_name,
                    'telegram_full_name' => $callback->telegram_full_name,
                    'user_name' => $callback->user?->name,
                    'created_at' => $callback->created_at->format('d/m/Y H:i:s'),
                    'time_ago' => $callback->created_at->diffForHumans(),
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $callbacks,
            'latest_id' => $callbacks->first()['id'] ?? $sinceId,
        ]);
    }
}

