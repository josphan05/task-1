<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'id',
    'placeholder',
    'multiple',
    'showSelectAll',
    'required',
    'disabled',
    'label',
    'labelClass',
    'options',
    'selected',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'id',
    'placeholder',
    'multiple',
    'showSelectAll',
    'required',
    'disabled',
    'label',
    'labelClass',
    'options',
    'selected',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="coreui-multi-select-wrapper">
    <?php if($label): ?>
    <label for="<?php echo e($id); ?>" class="form-label <?php echo e($labelClass); ?>">
        <?php echo e($label); ?>

        <?php if($required): ?>
        <span class="text-danger">*</span>
        <?php endif; ?>
    </label>
    <?php endif; ?>

    <select
        name="<?php echo e($name); ?><?php echo e($multiple ? '[]' : ''); ?>"
        id="<?php echo e($id); ?>"
        class="<?php echo e($multiple ? 'form-multi-select' : 'form-select'); ?> <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        <?php if($multiple): ?>
        multiple
        data-coreui-search="global"
        <?php if($showSelectAll): ?> data-coreui-select-all="true" <?php endif; ?>
        <?php endif; ?>
        <?php echo e($required ? 'required' : ''); ?>

        <?php echo e($disabled ? 'disabled' : ''); ?>

        <?php echo e($attributes); ?>

    >
        <?php if(!$multiple && !$required): ?>
        <option value=""></option>
        <?php endif; ?>

        <?php echo e($slot); ?>


        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $value = is_array($option) ? ($option['value'] ?? $option['id'] ?? '') : $option;
                $text = is_array($option) ? ($option['text'] ?? $option['name'] ?? $option['label'] ?? $value) : $option;
                $isSelected = in_array($value, (array) $selected);
            ?>
            <option
                value="<?php echo e($value); ?>"
                <?php echo e($isSelected ? 'selected' : ''); ?>

            ><?php echo e($text); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php /**PATH C:\laragon\www\task-1\resources\views/components/select2.blade.php ENDPATH**/ ?>