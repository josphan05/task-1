<footer class="footer">
    <div>
        Core Laravel &copy; <?php echo e(date('Y')); ?>

    </div>
</footer>

<?php /**PATH C:\laragon\www\task-1\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>